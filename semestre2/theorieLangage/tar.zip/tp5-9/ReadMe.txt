
	
	
			Parties realiser : B,C,D,E,F
			partie encours de realisation : G 
			Parties restantes : de H à O 
