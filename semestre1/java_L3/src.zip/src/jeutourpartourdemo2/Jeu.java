/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jeutourpartourdemo2;

/**
 *
 * @author mathet
 */
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Jeu extends JFrame implements Runnable {
    
    JLabel label;
    private ArrayList<Joueur> joueurs = new ArrayList<>();
    int joueurEnCours = 0;
    
    public Jeu() {
        super("Demo jeu multijoueurs");
        this.setPreferredSize(new Dimension(250,50));
        label = new JLabel("Jeu non démarré");
        Container cp = this.getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(label, BorderLayout.CENTER);
        pack();
        setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public void demarrer() {
        new Thread(this).start();
    }
    
    public void ajoutJoueur(Joueur j) {
        joueurs.add(j);
    }
    
    public void actionJoueur(String action) {
        this.label.setText(action);
    }
    
    public synchronized void run() {
        while (true) {
            System.out.println("Joueur en cours = "+joueurEnCours);
            joueurs.get(joueurEnCours).jouerMonTour();
            joueurEnCours++;
            if (joueurEnCours >= joueurs.size()) {
                joueurEnCours = 0;
            }
        }
    }
}
