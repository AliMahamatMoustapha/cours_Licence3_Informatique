/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jeutourpartourdemo2;


/**
 *
 * @author mathet
 */
public class JeuTourParTourDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jeu jeu = new Jeu();
        jeu.ajoutJoueur(new JoueurGraphique("Joueur 1", jeu));
        jeu.ajoutJoueur(new JoueurGraphique("Joueur 2", jeu));
        jeu.ajoutJoueur(new JoueurConsole("Joueur 3", jeu));
        jeu.demarrer();

    }

}
