/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jeutourpartourdemo2;

import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author mathet
 */
public class JoueurGraphique extends JFrame implements Joueur, ActionListener {

    private String nom;
    private final Jeu jeu;
    private boolean cEstMonTour = false;
    private JButton bOui, bNon;
    private static int rang = 0;
    private final static int DIM=200;

    public JoueurGraphique(String nom, Jeu jeu) {
        super(nom);
        this.nom = nom;
        this.jeu = jeu;
        this.setBounds(rang*DIM, 100, rang*DIM+DIM,100); 
        this.setPreferredSize(new Dimension(DIM,80));
        rang++;
        Container cp = this.getContentPane();
        cp.setLayout(new BorderLayout());
        bOui = new JButton("Oui");
        bOui.addActionListener(this);
        bNon = new JButton("Non");
        bNon.addActionListener(this);
        cp.add(bOui, BorderLayout.NORTH);
        cp.add(bNon, BorderLayout.SOUTH);
        this.pack();
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        System.out.println("dans action performed " + cEstMonTour);

        if (!cEstMonTour) {
            return;
        }

        if (e.getSource() == bOui) {
            jeu.actionJoueur(nom + " dit Oui");
        }
        if (e.getSource() == bNon) {
            jeu.actionJoueur(nom + " dit Non");
        }
        this.cEstMonTour = false;
        synchronized (jeu) {
            jeu.notifyAll();
        }

    }

    @Override
    public void jouerMonTour() {
        this.cEstMonTour = true;
        synchronized (jeu) {
            try {
                jeu.wait();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

    }

}
