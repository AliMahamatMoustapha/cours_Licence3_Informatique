/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jeutourpartourdemo2;

import java.util.Scanner;

/**
 *
 * @author mathet
 */
public class JoueurConsole implements Joueur {

    private Jeu jeu;
    private String nom;
    public JoueurConsole(String nom, Jeu jeu)
    {
        this.nom=nom;
        this.jeu=jeu;
    }
    @Override
    public void jouerMonTour() {
        Scanner scan = new Scanner(System.in);
        String s=scan.next();
        jeu.actionJoueur("(Console)"+nom+" dit : "+s);
    }

}
