
public abstract class AjoutOuRetrait implements OperationBancaire {
        
}
