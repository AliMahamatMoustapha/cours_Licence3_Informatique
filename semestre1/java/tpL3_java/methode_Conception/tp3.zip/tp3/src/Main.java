public class Main {
    public static void main(String[] args) {
      
        System.out.println(new Date(24,9,2018).compareTo(new Date(31,8,2018))); //true
        System.out.println(new Date(4,9,2018).compareTo(new Date(1,7,2019))); // tr
    }
}
