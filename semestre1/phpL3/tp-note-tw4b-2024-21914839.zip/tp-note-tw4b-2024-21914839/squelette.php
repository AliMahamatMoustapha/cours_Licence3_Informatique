<!DOCTYPE html>
<html lang="fr">

    <head> 
        <link rel="stylesheet" href="style/styleSite.css"  >
        <meta name="author" content="21914839" >
        <title><?php echo($title); ?></title>
        <meta charset="utf-8">

    </head>

    <body>
        <!-- <header>
        <nav class="menu">
            <ul>
            </ul>
        </nav>
        </header> -->
        <main>
            <h1><?php  echo($title) ; ?></h1>

            <div>
                   <?php echo($content);?> 
            </div>
        </main>
       

    </body>

</html>