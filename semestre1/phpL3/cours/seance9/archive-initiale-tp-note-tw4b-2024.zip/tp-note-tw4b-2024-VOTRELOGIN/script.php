<?php
echo 'Hello world pour tester le serveur. Une petite notice PHP pour voir à quoi ça ressemble :';
echo $variable_inexistante;


