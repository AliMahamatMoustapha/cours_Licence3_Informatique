 <?php
        include("./includes/donnees.php") ;
        //tableau qui contient les liens de la page 
        $tabLiens = array(
        "Tous les messages" => "liste.php?chercher",
        "Filtrer"  => "filtre.php",
        "Ajouter" => "ajout.php"

     ) ;
            $corp="<ul class=\"forum\">";
            //$chercher = key_exists("chercher" , $_GET)?$_GET["chercher"]:null;
            $i = 0 ;
                while ($i < count($donnees) ){
                    //if(strpos($donnees[$i]['texte'],$chercher)!==false){
                        $date = $donnees[$i]['date']->format('Y-m-d H:i:s'); 
                        $text = $donnees[$i]['texte'] ;
                        $pseudo = $donnees[$i]['pseudo'] ;
                        $corp.="<li class=\"mess\">par <strong>$pseudo</strong>, le $date<br> <p>$text</p></li>";//}
                $i++ ;
            }
            $corp.=" </ul>";
            
           /*  else{
                //affichons les messages 
                $i = 0 ;
                while ($i < count($donnees) ){
                $date = $donnees[$i]['date']->format('Y-m-d H:i:s'); 
                $text = $donnees[$i]['texte'] ;
                $pseudo = $donnees[$i]['pseudo'] ;
                echo  '<li>par <strong>'.$pseudo.'</strong>, le '.$date.' <br> <p>'.$text.'</p></li>';
                    $i++ ;
                }

            } */
            
            include("./includes/squelette.php") ;
?>