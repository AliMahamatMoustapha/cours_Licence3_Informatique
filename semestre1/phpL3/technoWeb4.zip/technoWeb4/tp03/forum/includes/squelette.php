<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Forum</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./styles/screen.css">
</head>
<body>
    <header>

        <nav>
                    <ul>
                    <?php 
                           foreach($tabLiens as $nom=>$lien){
                             echo "<li><a href=\"$lien\">$nom</a></li>" ;
                           }
                        ?>

                    </ul>
        </nav>
    </header>
    <main>
                    <h1>Forum</h1>
                    <?php
                        echo $corp ;
                    
                    ?>
           
    </main> 
        
</body>
</html>