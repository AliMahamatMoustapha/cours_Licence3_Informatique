<?php 
require_once('model/Animal.php') ;
require_once('model/AnimalBuilder.php') ;
class Controller {
    protected $view ;
    protected $animalStorage;
    
    public function __Construct($v,AnimalStorage $animalStorage){
        $this->view = $v ;
        $this->animalStorage = $animalStorage;
    }

    public function showInformation($id){
        if ($this->animalStorage->read($id)!=null){

            $this->view->prepareAnimalPage($this->animalStorage->read($id)); 

        }
        else {
            $this->view->prepareUnknownAnimalPage() ;
        }
        
    }
    public function showHommePage(){
        $this->view->homePage();
    }
    public function showList(){

        $this->view->prepareListPage($this->animalStorage->readAll()) ;
    }
    public function createNewAnimal(){

        $this->view->prepareAnimalCreationPage(new AnimalBuilder());
    }
    // public function saveNewAnimal($data) {
    //     $animalBuilder = new AnimalBuilder($data); 
    //     if ($animalBuilder->isValid()) {
    //         $animal = $animalBuilder->createAnimal();
    //         $path = 'uploads/'.$animal->getImage();
    //         $_FILES['image']['uploads/'];
    //         $animal->setImage($path);
    //         $id = $this->animalStorage->create($animal);
    //         $this->view->displayAnimalCreationSuccess($id);
    //     } 
    //     else {
    //         $this->view->prepareAnimalCreationPage($animalBuilder);
    //     }
    // }
    public function saveNewAnimal($data) {
        $animalBuilder = new AnimalBuilder($data); 

        if ($animalBuilder->isValid()) {
            $imagePath = null;

            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (in_array($_FILES['image']['type'], $allowedTypes)) {
                    $uploadDir = 'uploads/';
                    $imageName = uniqid() . '-' . basename($_FILES['image']['name']);
                    $destination = $uploadDir . $imageName;
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                        
                        $resizedImagePath = $this->resizeImage($destination, 300, 300);
                        $imagePath = $resizedImagePath;
                        
                    } else {
                        echo "Erreur lors du téléchargement de l'image.";
                    }
                } else {
                    echo "Le type de fichier n'est pas autorisé.";
                }
            }

            $animal = $animalBuilder->createAnimal();
            $animal->setImage($imagePath);

            $id = $this->animalStorage->create($animal);

            $this->view->displayAnimalCreationSuccess($id);
        } else {
            $this->view->prepareAnimalCreationPage($animalBuilder);
        }
    }


    public function showApropos(){
        $this->view->aboutPage();
    }
    private function resizeImage($filePath, $newWidth, $newHeight) {
        list($width, $height, $type) = getimagesize($filePath);

        switch ($type) {
            case IMAGETYPE_JPEG:
                $image = imagecreatefromjpeg($filePath);
                break;
            case IMAGETYPE_PNG:
                $image = imagecreatefrompng($filePath);
                break;
            case IMAGETYPE_GIF:
                $image = imagecreatefromgif($filePath);
                break;
            default:
                return false;
        }

        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        $newFilePath = 'uploads/resized_' . basename($filePath);

        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($newImage, $newFilePath, 90);
                break;
            case IMAGETYPE_PNG:
                imagepng($newImage, $newFilePath);
                break;
            case IMAGETYPE_GIF:
                imagegif($newImage, $newFilePath);
                break;
        }

        imagedestroy($image);
        imagedestroy($newImage);

        return $newFilePath;
    }
    
}
    
?>