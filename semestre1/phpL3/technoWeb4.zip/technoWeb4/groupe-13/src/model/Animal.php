<?php
 class Animal implements JsonSerializable{
    protected $nom , $species , $age ,$image;

    public function __Construct($n,$s ,$a,$img=null){
        $this->nom = $n ;
        $this->species = $s ;
        $this->age = $a ;
        $this->image = $img; 
       
    }

    public function getNom(){
        return $this->nom ;
    }

    public function getSpecies(){
        return $this->species ;
    }

    public function getAge(){
        return $this->age ;
    }
    public function jsonSerialize() {
        return array("nom"=>$this->nom,"espece"=>$this->species,"age"=>$this->age);
    }
    public function setImage($imagePath) {
        $this->image = $imagePath; 
    }
    public function getImage() {
        return $this->image;
    }

 }
?>