<?php
   
    require_once("model/AnimalStorage.php");

class AnimalStorageMySQL implements AnimalStorage{
    protected $pdo ;
    public function __Construct($pdo){
       $this->pdo = $pdo;
       $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }

    public function read($id){
        $stmt=$this->pdo->prepare("SELECT * From animals WHERE id= :id");
        $stmt->bindParam(':id',$id);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC); 
        return count($data )===0?null:new Animal($data[0]["name"],$data[0]["species"],$data[0]["age"],$data[0]["image"]);
    }
    public function readAll(){
        $data=array();
        $query = $this->pdo->query("SELECT * From animals;");
        $brutData = $query->fetchAll(PDO::FETCH_ASSOC); 
        foreach($brutData as $key => $value)
        {
            $data[$value["id"]] = new Animal($value["name"],$value["species"],$value["age"],$value["image"]);
        }
        return $data;

    }
    // la finction create permet d'ajouter à la base l'animal donné en argument, et retourne l'identifiant de l'animal ainsi créé
    public function create(Animal $a){
        $name = $a->getNom();
        $species = $a->getSpecies();
        $age = $a->getAge();
        $image = $a->getImage();
        // echo("image ".$image) ;
        $requette = 'INSERT INTO animals (name ,species,age, image) VALUES (:name, :species, :age, :image)';
        $stmt = $this->pdo->prepare($requette);
        $stmt->bindValue(':name',$name,PDO::PARAM_STR);
        $stmt->bindValue(':species',$species,PDO::PARAM_STR);
        $stmt->bindValue(':age',$age,PDO::PARAM_INT);
        $stmt->bindValue(':image', $image, PDO::PARAM_STR);
        $stmt->execute();
        return $this->pdo->lastInsertId();
    }
    
    /* la fonction delet permet de suprimer  de la base l'animal correspondant à l'identifiant donné en argument ;
    retourne true si la suppression a été effectuée et false si l'identifiant ne correspond à aucun animal. 
    */
    public function delete($id){
        $prepareStat = $this->pdo->prepare("DELETE FROM animals WHERE id=:id;") ;
        $prepareStat->bindValue(':id',$id,PDO::PARAM_INT); 
        if ($prepareStat->execute()) {
			return true;
		}
		return false;
    }
    
    /* la fonction update met àjour et retourne true si la mise à jour a bien été effectuée, 
    et false si l'identifiant n'existe pas (et donc rien n'a été modifié). 
    */
    public function update($id, Animal $a){
        $name = $a->getNom(); $species = $a->getSpecies(); $age = $a->getAge(); $image = $a->getImage();
        $prepareStat = $this->pdo->prepare("UPDATE animals SET name=:name,
            species=:species,age=:age,image=:image    
            WHERE id=:id;") ;
        $prepareStat->bindValue(':name',$name,PDO::PARAM_STR); 
        $prepareStat->bindValue(':species',$species,PDO::PARAM_STR); 
        $prepareStat->bindValue(':age',$age,PDO::PARAM_STR);
        $prepareStat->bindValue(':image',$image,PDO::PARAM_STR);
        $prepareStat->bindValue(':id',$id,PDO::PARAM_INT); 
        if ($prepareStat->execute()) {
			return true;
		}
		return false;

    }
}
?>