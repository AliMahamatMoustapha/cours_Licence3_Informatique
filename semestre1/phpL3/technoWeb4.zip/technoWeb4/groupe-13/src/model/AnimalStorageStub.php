<?php
require_once("model/AnimalStorage.php");
class AnimalStorageStub implements AnimalStorage{
    protected $animalsTab;

    function __Construct(){

            $this->animalsTab = array(
                'medor' => new Animal('Médor', 'chien',2),
                'felix' => new Animal('Félix', 'chat',3),
                'denver' => new Animal('Denver', 'dinosaure',5),
            );
    }
   
    public function read($id){
    
        return key_exists($id,$this->animalsTab)?$this->animalsTab[$id]:null;
    }

    public function readAll(){
        return $this->animalsTab;
}
    public function delete($id){
            echo("exceptiondelete");
    }
    public function update($id, Animal $a){
        echo("exceptionUpdate");

    }
    public function create(Animal $a){
        echo("exceptionCreate");
    }
}
?>