<?php

class AnimalBuilder{
    protected $data ,$error;
    const NAME_REF = 'nom';
    const SPECIES_REF = 'espece';
    const AGE_REF = 'age';
    const IMG_REF = "image";
    function __Construct($data=null){

        $this->data = $data ===null ? array(self::NAME_REF=>"",self::SPECIES_REF=>"",self::AGE_REF=>"",self::IMG_REF) : $data;
        $this->error = null;
    }

    public function getData($champ){
        return $this->data[$champ];
    }

    public function getError($champ){
        return ($this->error!==null && key_exists($champ,$this->error) ? $this->error[$champ] : "");
    }
    
    public function createAnimal(){

        $nom = $this->data[self::NAME_REF];
        $espece = $this->data[self::SPECIES_REF];
        $age = $this->data[self::AGE_REF];
        $image = $this->data[self::IMG_REF];
        $nouveauAnimal = new Animal($nom,$espece,$age,$image);
        return $nouveauAnimal ;

    }
    public function isValid(){
        $this->error = array();
        if(!key_exists(self::NAME_REF,$this->data) || $this->data[self::NAME_REF]==="")
            $this->error[self::NAME_REF] = "nom incorrect";
        if(!key_exists(self::SPECIES_REF,$this->data) || $this->data[self::SPECIES_REF]==="")
            $this->error[self::SPECIES_REF] = "espece incorrect";
        if(!key_exists(self::AGE_REF,$this->data) || $this->data[self::AGE_REF]==="" || $this->data[self::AGE_REF]<0)
            $this->error[self::AGE_REF] = "age invalide";
        // if(!in_array(explode('.',self::IMG_REF)[1],array('png','jpeg','gif')))
        //     $this->error[self::AGE_REF] = "image invalide";
        return count($this->error)===0;
    }
}

?>