<!DOCTYPE html>
<html lang="fr">

    <head> 
        <link rel="stylesheet" href="style/styleSite.css"  >
        <meta name="author" content="21914839" >
        <title><?php echo($this->title); ?></title>
        <meta charset="utf-8">

    </head>

    <body>
        <div> <p><?php echo ($this->feedback);?></p></div>
        <header>
        <nav class="menu">
            <ul>
                <?php
                    foreach($this->getMenu() as $title => $url){
                        echo '<li><a href="'.$url.'">'.$title.'</a></li>';
                    }
                
                ?>
            </ul>
        </nav>
        </header>
        <main>
            <h1><?php  echo($this->title) ; ?></h1>

            <div>
                   <?php echo($this->content);?> 
            </div>
        </main>
       

    </body>

</html>