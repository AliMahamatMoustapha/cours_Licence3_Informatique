<?php

    class ViewApi{
        protected $contentJson,$routerApi ; 

        public function __Construct($r){
            $this->routerApi = $r ;
        }
        public function renderApi(){
            header('Content-Type: application/json; access-control-allow-origin:* ');
            echo($this->contentJson) ;
            die();
        }
        function prepareAnimalPage( $animalJson){
           
            $this->contentJson = json_encode($animalJson);
        }
        function prepareListPage($data){
            $datajson = array();
            $i = 0;
            foreach($data as $id => $animal){
                 $a =array('id'=> $id,'nom'=> $animal->getNom());
                 $datajson[$i] =$a;
                 $i+=1;
                }
            $this->contentJson = json_encode($datajson, JSON_UNESCAPED_UNICODE);

        }
    }

?>