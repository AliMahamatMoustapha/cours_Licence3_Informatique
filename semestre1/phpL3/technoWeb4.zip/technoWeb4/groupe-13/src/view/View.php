<?php 
class View{
    protected $title,$content,$router,$feedback;
    public function __Construct($router,$feedback){
        $this->router = $router;
        $this->feedback = $feedback;
    }
    public function render(){
        include('view/squelette.php');
    }
    public function prepareTestPage(){
            $this->title="title de mon  projet " ;
            $this->content="contenu de mon projet ";
    }
    public function prepareAnimalPage(Animal $animal){
        $name = $animal->getNom();
        $species = $animal->getSpecies();
        $age = $animal->getAge() ;
        $image = $animal->getImage(); 

        $this->title="Page sur $name" ;
        $this->content=' <p>'.$name.' est un animal agé de '.$age.' ans et d\'espèce '. $species.' </p>
                            <button type="button" id="supprimer">Supprimer</button>
                            <button type="button" id="modifier">Modifier</button>
                            ';
        $this->content .= '<img src="' .$image. '" alt="Image de ' . htmlspecialchars($animal->getNom()) . '"/>';

    }
    public function prepareUnknownAnimalPage(){
        $this->title="UnknowAnimal" ;
        $this->content="Animal inconnu";
    }
    public function homePage(){
        $this->title="Accueil" ;
        $this->content="<div>
                    <h4>Bienvenue sur notre site de gestion des animaux !</h4>
                    <p>
                        Ici, vous pouvez facilement ajouter, modifier, supprimer et afficher une liste d'animaux.
                        Que ce soit pour gérer vos animaux de compagnie, ou simplement organiser une collection, 
                        notre plateforme vous offre toutes 
                        les fonctionnalités dont vous avez besoin pour tout garder sous contrôle
                    </p>
                    </div>";
    
    }
    public function prepareListPage($animalTab){
       
        $this->title="Liste animals" ;
        $this->content="<ul>";
        foreach($animalTab as $id => $animal){
            $name = $animal->getNom() ;
            $url = $this->router->getAnimalURL($id);
            $this->content .='<li><a href="'.$url.'">'.htmlspecialchars($name,ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5 ,"UTF-8").'</a></li>' ;
        }

        $this->content .="</ul>" ;
    }
    public function getMenu(){
        return array(
            "Accueil" => $this->router->getAccueilUrl(),
            "Animals" => $this->router->getAnimalsUrl(),
            "Ajouter" => $this->router->getAnimalCreationURL(),
            "Apropos" => $this->router->getAboutUrl(),

        );
    }
    public function prepareDebugPage($variable) {
        $this->title = 'Debug';
        $this->content = '<pre>'.htmlspecialchars(var_export($variable, true)).'</pre>';
    }
    public function prepareAnimalCreationPage(AnimalBuilder $animalBuilder){
        $this->title = "Creer un nouveau Animal";
        $action = $this->router->getAnimalSaveURL();
        $methode = "POST";
        $nom = htmlspecialchars($animalBuilder->getData(AnimalBuilder::NAME_REF),ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5 ,"UTF-8");
        $espece = htmlspecialchars($animalBuilder->getData(AnimalBuilder::SPECIES_REF),ENT_QUOTES|ENT_SUBSTITUTE|ENT_HTML5,"UTF-8");
        $age = htmlspecialchars($animalBuilder->getData(AnimalBuilder::AGE_REF),ENT_QUOTES|ENT_SUBSTITUTE|ENT_HTML5,"UTF-8");
        $nomErr = $animalBuilder->getError(AnimalBuilder::NAME_REF);
        $especeErr = $animalBuilder->getError(AnimalBuilder::SPECIES_REF);
        $ageErr = $animalBuilder->getError(AnimalBuilder::AGE_REF);
        $this->content = '<form action="'.$action.'" method="'.$methode.'">
                            <p>
                            <label> 
                                Nom : <input type="text" name="nom" value="'.$nom.'">                           
                                <span>'.$nomErr.'</span>
                            </label>
                        
                             <label> 
                                Espece : <input type="text" name="espece" value="'.$espece.'">
                                
                                <span>'.htmlspecialchars($especeErr).'</span>

                            </label>
                         
                             <label> 
                                Age : <input type="text" name="age" value="'.$age.'">
                               
                                <span>'.htmlspecialchars($ageErr).'</span>

                            </label>
                             <label>
                                Image : <input type="file" name="image">
                            </label>
                            <input type="submit" value="Ajouter">
                            </p>
                          </form>';
    } 
    public function displayAnimalCreationSuccess($id){
        $animalUrl = $this->router->getAnimalURL($id);
        $this->router->POSTredirect($animalUrl,"L'animal à été ajouter avec succés");
    }
    public function aboutPage(){
        $this->title = "A propos";
        $this->content = '<div>
        <h3>Realiser par :</h3>
        <ul>
            <li>Ali Mahamat Moustapha(21914839)</li>
            <li>Yasmine Habil(22209506)</li>
        </ul>
        <div>
                <h3> Architecture MVCR </h3>
            <p>
                Nous avons appliquer l\'architecture MVCR et les consignes données.<br>
                Le code est bien séparé entre la vue, le model; le controller et <br>
                le router.
            </p>
        </div>

        <div>
                <h3> Sécurité </h3>
            <p> 
                Le site est non vilnérable aux injections xss et aux scriptes javaScript.<br>
                Nous avons realiser des requettes preparer pour échapper à ses sortes d\'incident<br>
                aux injections sql<br>
            </p>
        </div>
        
        </div> ';
    }
}
?>