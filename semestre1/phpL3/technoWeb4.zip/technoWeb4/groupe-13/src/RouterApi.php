<?php
require_once("view/ViewApi.php");
require_once("control/Controller.php");

class RouterApi{
    public function main($animalStorage){
        $collection = key_exists('collection',$_GET) ? $_GET['collection'] :null;
        $id = key_exists('id',$_GET) ? $_GET['id'] : null;
        $viewJson= new ViewApi($this) ;
        $controller = new Controller($viewJson,$animalStorage) ;

        if(key_exists('collection',$_GET)){
            switch ($collection) {
                case 'animaux':
                    if(key_exists('id',$_GET)){

                       $controller->showInformation($_GET['id']);

                    }
                    else{

                        $controller->showList();

                    }
                    break;

                default:
                    # code...
                    break;
            }
        }
        $viewJson->renderApi();

    }
}

?>