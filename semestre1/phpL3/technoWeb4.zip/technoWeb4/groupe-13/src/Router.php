<?php 
require_once("view/View.php");
require_once("control/Controller.php");
// require_once("model/AnimalStorageStub.php");
class Router{

    public function main($animalStorage){

       $feedback = key_exists('feedback',$_SESSION)?$_SESSION['feedback']:"";
       $_SESSION['feedback'] ="";
        $view= new View($this,$feedback) ;
        $feedback = "";
        $controller = new Controller($view,$animalStorage) ;
        if (key_exists('id',$_GET)){
            $id = $_GET['id'];
            $controller->showInformation($id) ;
           
        }
        else if(key_exists('action',$_GET)){
            $action = $_GET['action'];
            switch ($action) {

                case "list" :
                    $controller->showList();
                    break;
                case "nouveau" :
                    $controller->createNewAnimal();
                    break ;
                case "sauverNouveau":
                    $controller->saveNewAnimal($_POST);
                    break ;
                case "about":
                    $controller->showApropos();
                    break ;
                // case "update":
                //     if(key_exists('id',$_GET)){
                //         $this->controller->showUpdatePage($_GET['id']);
                //     }
                

            }

          
        }
        else{
            $controller->showHommePage();
           

        }
        $view->render();
    }
    public function getAnimalURL($id) {
        return "site.php?id=".$id ;
    }
   public  function getAccueilUrl(){
        return "site.php";
    }
    public function getAnimalsUrl(){
        return "site.php?action=list" ;
    }
   public  function getAnimalCreationURL(){
        return "site.php?action=nouveau";
    }
    public function getAnimalSaveURL(){
        return "site.php?action=sauverNouveau";
    }
    public function POSTredirect($url, $feedback){
        $_SESSION['feedback'] = $feedback;
        header('Location: '.$url,true,303);
        die();

    }
    public function getAboutUrl(){
        return "site.php?action=about";
    }
}


?>