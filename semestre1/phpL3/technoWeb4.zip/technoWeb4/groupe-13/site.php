<?php

/*
 * On indique que les chemins des fichiers qu'on inclut
 * seront relatifs au répertoire src.
 */
set_include_path("./src");
require_once("model/AnimalStorageMySQL.php");
/* Inclusion des classes utilisées dans ce fichier */
require_once("Router.php");
include("../../../private/mysqlConfi.php");
session_start() ;

 
/*
 * Cette page est simplement le point d'arrivée de l'internaute
 * sur notre site. On se contente de créer un routeur
 * et de lancer son main.
 */
$pdo = new PDO(DNS, UTILISATEURS, MOTDEPASSE);
$animalStorageMysql = new AnimalStorageMySQL($pdo);
// echo $animalStorageSession.;
$router = new Router();
$router->main($animalStorageMysql);

?>
