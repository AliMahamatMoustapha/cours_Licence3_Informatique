<?php 
set_include_path("./src");
include("../../../private/mysqlConfi.php");
require_once("RouterApi.php");
require_once("model/AnimalStorageMySQL.php");

$pdo = new PDO(DNS, UTILISATEURS, MOTDEPASSE);
$animalStorageMysql = new AnimalStorageMySQL($pdo);
$routerApi = new RouterApi();
$routerApi->main($animalStorageMysql);

?>