<h2>membres du projet : </h2>
<ul>
	<li>Moustapha Ali Mahamat(21914839)</li>
	<li>Yasmine Habil(22209506) </li>

</ul>
<h2>la répartition des compléments :</h2>
<ul>
	<li>Moustapha Ali Mahamat : Complement 2 Url  : [api.php?collection=animaux](https://dev-21914839.users.info.unicaen.fr/technoWeb4/groupe-13/api.php?collection=animaux) </li>
	<li>Yasmine Habil : Complement 1 </li>

</ul>
<h4>
Url du site : [https://dev-21914839.users.info.unicaen.fr/technoWeb4/groupe-13/site.php](https://dev-21914839.users.info.unicaen.fr/technoWeb4/groupe-13/site.php)
</h4>

<h3>Le Zip Deposé sur ecampus par : Ali Mahamat Moustapha</h3>