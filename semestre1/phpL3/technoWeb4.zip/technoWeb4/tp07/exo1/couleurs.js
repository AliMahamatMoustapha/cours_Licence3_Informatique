"use strict";

let butt=document.getElementById("plus");
let liste=document.getElementById("couleurs");
butt.addEventListener("click" ,affiche);




function affiche(event){
    const xhr= new XMLHttpRequest();
    console.log(event);
    xhr.addEventListener("load",(event)=>{
        console.log(event.currentTarget.response);
        const res=event.currentTarget.response;
        for(let i=0;i<res.length;i++){
            const item=document.createElement("li");
            const bt=document.createElement("button");
            bt.textContent=res[i]["name"];
            bt.addEventListener("dblclick",()=>{
                item.style.backgroundColor="";
            });
            bt.addEventListener("click",()=>{
                item.style.backgroundColor="red";
            });
            item.appendChild(bt);
            // item.textContent=res[i]["name"];
            liste.appendChild(item);

        }
        // console.log(res[0]["name"]);
    });
    

    xhr.open("GET","https://ensweb.unicaen.fr/TW4b/tp/couleurs-ajax/service.php",true);
    xhr.responseType="json";
    xhr.send();
}