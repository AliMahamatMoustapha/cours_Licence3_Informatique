<?php 
    include("codepostal.php");
    function getNameCommune($get){
        
    }

?>