<?php
$date_creation = date("d-m-y H:i:s") ;
setcookie("laste_visit",$date_creation,time()+60*60*24*365) ;

if(isset($_COOKIE["laste_visit"])){
    
    echo "votre derniere visit c'etait le ".$_COOKIE['laste_visit'] ;
}
else {
    echo "votre premiere visite " ;
}

?>
<h1>bonjour</h1>