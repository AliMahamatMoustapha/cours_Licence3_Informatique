<?php
include("../../../../private/mysqlConfi.php");
try{
    $pdo = new PDO(DNS,UTILISATEURS, MOTDEPASSE) ;
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = 'SELECT * FROM images' ;

    echo "<h3>thumbnail</h3><ol>" ;
    foreach ($pdo->query($sql) as $row) {
        echo "<li>$row[title] <a href=image.php?id=34 ><img src=\"$row[thumb_url]\"</a>/></li>";
        /* echo "<li><img src=\"$row[image_page_url]\"/></li>";
        echo "<li><img src=\"$row[author_url]\"/></li>";

 */
    }
    echo "</ol>" ;
   
}catch(PDOException $e){
    echo "Échec de la connexion : " . $e->getMessage();
}



?>