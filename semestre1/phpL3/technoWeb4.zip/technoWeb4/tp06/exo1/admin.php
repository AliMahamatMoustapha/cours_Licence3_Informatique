<?php 
session_start();
if($_SESSION["user"]["status"]==="admin"){
    echo '<h3>Partie admin</h3>
            <p>Vous etes bien admin!</p>
    
            ';
}
else{
    echo '<h4> accés non autorisés </h4>';
}
?>