<?php 
session_start();
include('comptes.php');

function check($log,$pw,&$comptes){
    $boo=[];
    for($i=0;$i<count($comptes);$i++){
        if($comptes[$i]["login"]===$log && password_verify($pw,$comptes[$i]["pwHash"])){
            $boo["status"]=$comptes[$i]["status"];
            $boo["name"]=$comptes[$i]["name"];
        }
    }
    return $boo;
}
if(key_exists("login",$_POST) && key_exists("password",$_POST)){
    $log=$_POST["login"];
    $pw=$_POST["password"];
    if(check($log,$pw,$comptes)!=[]){
        $_SESSION["user"]=check($log,$pw,$comptes);
        header("location:index.php");
        die;
    }
    else{
        echo "le couple pw,login incorrecte";
    }

}
 

?>
<!DOCTYPE html>
<html>
<head>
	<title>Connexion et déconnexion — Exercice d'authentification</title>
	<meta charset="UTF-8" />
</head>
<body>
<h1>Page de connexion/déconnexion</h1>
<div><form method="POST" action="">
<label>Nom : <input type="text" name="login" /></label>
<label>Mot de passe : <input type="password" name="password" /></label>
<button>Se connecter</button>
</form>
</div>
<nav>
<ul>
	<li><a href="index.php">Page d'accueil</a></li>
	<li>Page de connexion/déconnexion</li>
</ul>
</nav>
</body>
</html>
