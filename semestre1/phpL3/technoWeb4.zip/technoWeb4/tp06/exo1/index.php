<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Exercice d'authentification</title>
	<meta charset="UTF-8" />
</head>
<body>
<h1>Bienvenue, <?php echo $_SESSION["user"]["name"];?> !</h1>
<p>Vous êtes sur la page d'accueil.</p>
<nav>
<ul>
	<li>Page d'accueil</li>
	<li><a href="connexion.php">Page de connexion/déconnexion</a></li>
	<li><a href="admin.php">Partie admin</a></li>
</ul>
</nav>
</body>
</html>
