<?php 

$form ='<form method=\"POST\"> 
    <input type="text" />
    <input type="text" />
    <input type="submit" />

</form>';
echo $form ;
?>
