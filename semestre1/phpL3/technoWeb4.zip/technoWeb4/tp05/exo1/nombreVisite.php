<?php
session_name("monsiteID");
session_start() ;

if(key_exists("restaure",$_POST)){
	session_destroy() ;
	header("location: nombreVisite.php") ;
	die;
}

if(key_exists('date',$_SESSION)){
	$_SESSION['compteur']+=1 ;

}
else{
	$_SESSION['date'] = date("Y-m-d H:i:s");
	$_SESSION['compteur'] = 0 ;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Compteur de visites</title>
	<meta charset="UTF-8" />
</head>
<body>
	<?php var_export($_POST); var_export($_SESSION);  ?>
	<h1>Compteur de visites</h1>
	<p>Vous avez visité cette page <?php echo $_SESSION['compteur'] ; ?>
	 fois depuis <?php echo $_SESSION['date']; ?></p>
	<form  method="POST">
    <button  name="restaure">reinitialiser</button> 
	</form>
</body>
</html>


